import React from 'react'
    // Täällä vain luodaan kontekstielementti
    export const AppContext = React.createContext()

